import React, { useState, useEffect } from "react";
import * as bookingApi from "../ApiCalls/bookApi";
import BookingForm from "./bookingForm";

function Booking(props) {
    const [bookOrder, setbookOrder] = useState({
        name: "",
        email: "",
        room: "",
        checkin: "",
        checkout: "",
        noofrooms: "",
    });

    const [deleteOrder, setDeleteOrder] = useState({
        email: ""
    });

    const [errors, setErrors] = useState({});

    function handleChange({ target }) {
        
        setbookOrder({
            ...bookOrder,   
            [target.name]: target.value,  
        });
    }

    function onDeleteChange({ target }) {
        setDeleteOrder({
            ...deleteOrder,
            [target.name]: target.value,
        });
    }

    function handleDateChange(field, value) {
        setbookOrder({
            ...bookOrder,
            [field]: value,
        });
    }

    function ValidForm(params) {
        const _errors = {};
        if (!bookOrder.name) _errors.name = "Please enter your name";
        if (!bookOrder.email) _errors.email = "Please enter your email";
        if (!bookOrder.checkin)
            _errors.checkin = "Please choose your checkin date...";
        if (!bookOrder.checkout)
            _errors.checkout = "Please enter your checkout date...";
        if (!bookOrder.noofrooms)
            _errors.noofrooms = "Please enter number of rooms...";
        if (bookOrder.checkin && bookOrder.checkout) {
            if (bookOrder.checkin.getTime() > bookOrder.checkout.getTime())
                _errors.checkout =
                    "Checkout date cannot be before checkin date...";
        }
        if (!bookOrder.room)
            _errors.room = "Please select one of the room types";
        setErrors(_errors);
        // console.log(errors);
        return Object.keys(_errors).length === 0;
    }

    function handleSubmit(evt) {
        evt.preventDefault();
        if (!ValidForm()) return;
        bookingApi.validateRequest(bookOrder).then(() => {
            alert("Booking added successfully!");
        });
    }

    function handleDelete(evt){
        
        evt.preventDefault();
        bookingApi.deleteBooking(deleteOrder)
        // .then(() => {
        //     alert("Booking deleted successfully!");
        // });
    }

    return (
        <BookingForm
            errors={errors}
            onDeleteChange={onDeleteChange}
            onChange={handleChange}
            onSubmit={handleSubmit}
            onDelete={handleDelete}
            deleteOrder={deleteOrder}
            bookOrder={bookOrder}
            handleDateChange={handleDateChange}
        />
    );
}

export default Booking;
