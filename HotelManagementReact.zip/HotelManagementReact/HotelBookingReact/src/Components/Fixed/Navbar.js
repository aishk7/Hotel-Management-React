import React from "react"

const item = {
	color: "white",
	paddingLeft: "20px",
	paddingRight: "20px",
};

function navbar() {
	return (
		<nav class="navbar navbar-expand-lg  bg-dark">
			<div
				className="collapse navbar-collapse"
				id="navbarSupportedContent"
			>
				<ul className="navbar-nav ml-auto">
					<li className="nav-item">
						<a className="nav-link" href="./home" style={item}>
							Home <span className="sr-only">(current)</span>
						</a>
					</li>
					<li className="nav-item">
						<a className="nav-link" href="./features" style={item}>
							Features
						</a>
					</li>
​
					<li className="nav-item">
						<a className="nav-link" href="./rooms" style={item}>
							Rooms
						</a>
					</li>
​
					<li className="nav-item">
						<a className="nav-link" href="./about" style={item}>
							About
						</a>
					</li>
​
					<li className="nav-item">
						<a className="nav-link" href="./contact" style={item}>
							Contact
						</a>
					</li>
​
					<li className="nav-item">
						<a className="nav-link" href="./booking" style={item}>
							Booking
						</a>
					</li>
				</ul>
			</div>
		</nav>
	);
}

export default navbar;