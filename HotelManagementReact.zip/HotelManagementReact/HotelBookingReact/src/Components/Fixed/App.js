// import logo from './logo.svg';
// import './App.css';
import Booking from "../Booking/booking";
import Navbar from "./Navbar";

function App() {
  return (
    <div>
    <Navbar />
    <Booking />
    </div>
  )
}

export default App;
